const path = require('path')

module.exports = {
  entry : './src/main.js',
  output : {
    path : path.resolve(__dirname,'dist'),//__dirname获取文件'dist'的绝对路径
    filename : 'bundle.js'
  },
  module: {
    rules: [
      {
        test: /\.css$/i,//正则匹配css文件
        use: ["style-loader","css-loader"],
      },
    ],
  }
}