const {add,mul} = require('./js/mathUtil.js')



console.log(add(20, 30));
console.log(mul(20, 30));

import {name,age,height} from "./js/info";

console.log(name);
console.log(age);
console.log(height);

require('./css/normal.css');



