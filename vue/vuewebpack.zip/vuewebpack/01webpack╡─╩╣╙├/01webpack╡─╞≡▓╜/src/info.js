export const name = 'itprwe'
export const age = 18
export const height = 1.77