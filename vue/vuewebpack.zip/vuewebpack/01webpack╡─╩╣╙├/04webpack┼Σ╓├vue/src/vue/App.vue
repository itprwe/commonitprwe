<!--<template>-->
<!--  <div>-->
<!--    <h2 class="title">{{ message }}</h2>-->
<!--    <p>{{ name }}</p>-->
<!--    <button @click="btnClick">按钮</button>-->
<!--    <Cpn></Cpn>-->
<!--  </div>-->
<!--</template>-->

<template>
  <div>
    123123
    <br>
    <input type="text" v-model="hello">
<!--    <keep-alive>-->
<!--      <component :message="hello"></component>-->
<!--    </keep-alive>-->
    <Cpn :message="hello"></Cpn>
  </div>
</template>


<script>
import Cpn from "./Cpn";

export default {
  name: "App",
  components:{
    Cpn
  },
  data() {
    return {
      // message: 'hello webpack',
      // name: 'gagaga',
      hello:"hello"//初始值
    }
  },
  methods: {
    btnClick(){
      console.log('click,,,,')
    }
  }
}
</script>

<style scoped>
.title{
  color: darkgreen;
}
</style>