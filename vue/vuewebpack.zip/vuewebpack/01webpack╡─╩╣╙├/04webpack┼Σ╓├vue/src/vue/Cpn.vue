<!--<template>-->
<!--  <div>-->
<!--    <h2>我是cpn组件的标题</h2>-->
<!--    <p>我是cpn组件的内容</p>-->
<!--    <h3>{{ name }}</h3>-->
<!--  </div>-->
<!--</template>-->

<template>
  <div>
    <p>{{message}}</p>
  </div>
</template>

<script>
export default {
  name: "Cpn",
  props:["message"],
  data() {
    return {
      // name: 'cpn组件的name'
    }
  }
}
</script>

<style scoped>

</style>