//将内容抽离到App.vue文件中
/**
export default  {
  template: `
    <div>
    <h2>{{ message }}</h2>
    <p>{{ name }}</p>
    </div>
  `,
  data() {
    return {
      message: 'hello webpack',
      name: 'gagaga'
    }
  },
  methods: {}
}
 */