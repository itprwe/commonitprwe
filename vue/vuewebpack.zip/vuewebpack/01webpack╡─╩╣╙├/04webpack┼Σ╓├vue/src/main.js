const {add, mul} = require('./js/mathUtil.js')


console.log(add(20, 30));
console.log(mul(20, 30));

//1. 依赖js
import {name, age, height} from "./js/info";

console.log(name);
console.log(age);
console.log(height);

//2.依赖css文件
require('./css/normal.css');


//3.使用Vue进行开发
import Vue from 'vue'

//1.方法一
/**
 const app = new Vue({
  el:'#app',
  template:`
  <div>
  <h2>{{message}}</h2>
  <p>{{name}}</p>
  </div>
  `,
  data:{
    message:'hello webpack',
    name:'gagaga'
  },
  methods:{

  }
})
 */
//2.方法二 抽出模板
/**
const App = {
  template: `
    <div>
    <h2>{{ message }}</h2>
    <p>{{ name }}</p>
    </div>
  `,
  data() {
    return {
      message: 'hello webpack',
      name: 'gagaga'
    }
  },
  methods: {}
}

const app = new Vue({
  el: '#app',
  template: '<App/>',
  components: {
    App
  }
})
*/

//3.方法三，创建app.js文件，直接在app.js文件中将App对象内容导出，再在main.js中导入使用即可
// import App from './vue/app.js'
import App from './vue/App.vue'
const app = new Vue({
  el: '#app',
  template: '<App/>',
  components: {
    App
  }
})


