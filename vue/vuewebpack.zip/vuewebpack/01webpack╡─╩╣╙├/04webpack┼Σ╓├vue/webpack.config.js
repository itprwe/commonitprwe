const path = require('path')
const webpack = require('webpack')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const UglifyjsWebpackPlugin = require('uglifyjs-webpack-plugin')

module.exports = {
  entry: './src/main.js',
  output: {
    path: path.resolve(__dirname, 'dist'),//__dirname获取文件'dist'的绝对路径
    filename: 'bundle.js',
    // publicPath:'dist/'
  },
  module: {
    rules: [
      {
        test: /\.css$/i,//正则匹配css文件
        use: ["style-loader", "css-loader"],
      },
      {
        test:/\.vue$/i,
        use:['vue-loader']
      }
    ],
  },
  resolve: {
    //alias别名
    extensions:['.vue','.js','.css'],//省略什么文件后缀则配置该文件
    alias: {
      'vue$':'vue/dist/vue.esm.js'
    }
  },
  plugins:[
    new webpack.BannerPlugin('最终版权归xxx所有'),
    new HtmlWebpackPlugin({
      template:'index.html'
    }),
    new UglifyjsWebpackPlugin()
  ],
  devServer:{
    contentBase:'./dist',
    inline:true
  }
}