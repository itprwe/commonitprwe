<template>
<div>
  <h2>我是Profile</h2>
  <p>档案啊档案</p>
  <p>{{$route.query.name}}</p>
</div>
</template>

<script>
export default {
  name: "Profile"
}
</script>

<style scoped>

</style>