<template>
<div>
  <h2>我是about页</h2>
  <p>哈哈哈哈哈哈哈</p>
</div>
</template>

<script>
export default {
  name: "About"
}
</script>

<style scoped>

</style>