<template>
<div>
  <ul>
    <li>消息1</li>
    <li>消息2</li>
    <li>消息3</li>
    <li>消息4</li>
  </ul>
</div>
</template>

<script>
export default {
  name: "HomeMessage"
}
</script>

<style scoped>

</style>