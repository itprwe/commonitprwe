<template>
<div>
  <h3>User的组件</h3>
  <h2>{{userId}}</h2>
</div>
</template>

<script>
export default {
  name: "User",
  computed:{
    userId(){
      return this.$route.params.userId
    }
  }
}
</script>

<style scoped>

</style>