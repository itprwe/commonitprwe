<template>
  <div>
    <h2>我是home页</h2>
    <p>哈哈哈哈哈哈哈</p>
    <router-link to="/home/news">新闻</router-link>
    <router-link to="/home/message">消息</router-link>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "Home",
  created() {
    console.log('home created');
  }
}
</script>

<style scoped>

</style>