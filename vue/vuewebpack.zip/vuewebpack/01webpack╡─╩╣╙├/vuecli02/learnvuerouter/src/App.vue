<template>
  <div id="app">
<!--    <router-link to="/home" tag="button" active-class="active">首页</router-link>-->
<!--    <router-link to="/about" tag="button" active-class="active">关于</router-link>-->

<!--    <router-link to="/home" tag="button">首页</router-link>-->
<!--    <router-link to="/about" tag="button">关于</router-link>-->

<!--    <button @click="homeClick">首页</button>-->
<!--    <button @click="aboutClick">关于</button>-->

    <router-link to="/home">首页</router-link>
    <router-link to="/about">关于</router-link>
<!--    <router-link :to="'/user/'+userId">用户</router-link>-->
<!--    <router-link :to="{path:'/profile',query:{name:'gagagad',age:18,address:'iiittt'}}">档案</router-link>-->

    <button @click="userClick">用户</button>
    <button @click="profileClick">档案</button>

    <keep-alive>
      <router-view></router-view>
    </keep-alive>
  </div>
</template>

<script>
export default {
  name: 'App',
  data(){
    return{
      userId:'gagaga'
    }
  },
  methods:{
    homeClick(){
      //通过代码方式修改路由，还是使用vue-router
      this.$router.push('/home')
      console.log("home");
    },
    aboutClick(){
      this.$router.push('/about')
      console.log("about");
    },
    userClick(){
      this.$router.push('/user/'+this.userId)
    },
    profileClick(){
      this.$router.push({
        path:'/profile',
        query:{
          name:'gagapro',
          age:13,
          height:1.88
        }
      })
    }
  }
}
</script>

<style>
.active{
  color:red;
}
</style>

