//0.配置路由相关信息
import VueRouter from 'vue-router'
import Vue from 'vue'

// import Home from "../components/Home";
// import About from "../components/About";
// import User from "../components/User";

const Home = () => import('../components/Home')
const HomeNews = () => import('../components/HomeNews')
const HomeMessage = () => import('../components/HomeMessage')
const About = () => import('../components/About')
const User = () => import('../components/User')
const Profile = () => import('../components/Profile')

//1.通过Vue.use(插件)，安装插件
Vue.use(VueRouter)
//2.命名一个变量存放关系
const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',//意味着只要路径里面出现了/home，则显示下面对应的组件
    component: Home,
    meta: {
      title: '首页'
    },
    children: [
      {
        path: '/',
        redirect: 'news'
      },
      {
        path: 'news',
        component: HomeNews,
        meta: {
          title: '新闻'
        }
      },
      {
        path: 'message',
        component: HomeMessage,
        meta: {
          title: '消息'
        }
      }
    ]
  },
  {
    path: '/about',
    component: About,
    meta: {
      title: '关于'
    },
    beforeEnter: (to, from, next) => {
      next()
    }
  },
  {
    path: '/user/:userId',
    component: User,
    meta: {
      title: '用户'
    }
  },
  {
    path: '/profile',
    component: Profile,
    meta: {
      title: '档案'
    }
  }
]
//3.创建路由VueRouter对象
const router = new VueRouter({
  mode: 'history',
  linkActiveClass: 'active',
  //4.配置路由和组件之间的关系
  routes
})
//前置守卫
// router.beforeEach((to, from, next) => {
//   //从from跳转到to
//   document.title = to.matched[0].meta.title
//   next()
// })

//后置钩子
router.afterEach((to, from) => {
  //从from跳转到to
  document.title = to.matched[0].meta.title
})

//5.将router对象传入到Vue实例中
export default router
//6.然后再在main.js中导入使用 import router from './router'，在Vue中使用
